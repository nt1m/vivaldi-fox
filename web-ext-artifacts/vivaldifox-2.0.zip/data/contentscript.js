/* eslint-env browser */
/* global chrome */
"use strict";
let extractPageColour = function() {
  let $ = (s) => document.querySelector(s);
  let el = $("meta[name='theme-color']") ? $("meta[name='theme-color']") :
                                           $("meta[name='msapplication-TileColor']");
  if (el) {
    chrome.runtime.sendMessage({
      type: "theme-colour-change",
      content: el.getAttribute("content")
    }, () => {});
  } else {
    chrome.runtime.sendMessage({
      type: "theme-colour-change",
      content: "default"
    }, () => {});
    self.port.emit("theme-colour-change", "default");
  }
};
extractPageColour();
